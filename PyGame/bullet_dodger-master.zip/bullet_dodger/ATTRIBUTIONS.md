### "Hitman" (song)

"Hitman"
Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 3.0
http://creativecommons.org/licenses/by/3.0/

### _Ground_ modified (texture)

_Ground_
Nekith (http://opengameart.org/content/ground)
Licensed under CC0 1.0 Universal (CC0 1.0)
https://creativecommons.org/publicdomain/zero/1.0/
