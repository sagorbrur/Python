## Description

A fun and challenging mouse game where you must dodge bullets.
How many points will you get?

## License

This game is free software. It uses the [GNU General Public License, version 3](https://notabug.org/jorgesumle/bullet_dodger/raw/master/LICENSE).
The licenses of music, artwork, sounds, etc. can be found in the
file [ATTRIBUTIONS.md](https://notabug.org/jorgesumle/bullet_dodger/raw/master/ATTRIBUTIONS.md).
