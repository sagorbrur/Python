2d shift puzzle. 

The initial display shows the solved puzzle. 
The first mouse click shuffles the tiles. 
After that, a left mouse click on a tile next to the empty tile moves that tile there. 
The right mouse button shows the solved puzzle image temporarily. 

The whole game is about 132 lines. 
It is meant to be a simple example of a 2d game with mouse control using pygame. 
It is also fun to play (for a while).
